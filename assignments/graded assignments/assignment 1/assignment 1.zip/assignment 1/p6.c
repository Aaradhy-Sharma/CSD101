#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

int main()
{
    // creating a program which displays the integer value of a character entered by the user //
    char a;
    printf("Enter a character to be displayed in integer form : ");
    scanf("%c",&a );
    printf("\n The integer value of %c = %d ", a , a);


    return 0;
}




















