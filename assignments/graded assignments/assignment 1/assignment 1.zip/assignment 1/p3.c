#include <stdio.h>
int main() 
{

 // circle //
 printf("\n     *     ");
 printf("\n           ");
 printf("\n*         *");
 printf("\n           ");
 printf("\n   *   *   ");

 // triangle //
 printf("\n    /\\     ");
 printf("\n           ");
 printf("\n   /  \\     "); // we use double backslash so that we can print it //
 printf("\n           ");
 printf("\n  ______   "); 

 // rectangle //
 printf("\n _________    ");
 printf("\n |        |  ");
 printf("\n |        |");
 printf("\n |        | ");
 printf("\n ----------");

 // initials //
 printf("\n   /\\     --------|");
 printf("\n  /  \\    |   ");
 printf("\n /----\\   |______ ");
 printf("\n/      \\         |");
 printf("\n           _______|");



 return 0;
}
